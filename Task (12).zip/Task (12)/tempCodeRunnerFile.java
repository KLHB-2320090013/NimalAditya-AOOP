//how to write hello world programming in java?
public Class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}