import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/VoterEligibilityServlet")
public class VoterEligibilityServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Set response content type
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get form parameters (name and age)
        String name = request.getParameter("name");
        String ageStr = request.getParameter("age");

        try {
            // Convert age string to integer and validate
            int age = Integer.parseInt(ageStr);

            // Check voter eligibility
            if (age >= 18) {
                out.println("<h2>Hello " + name + ", you are eligible to vote!</h2>");
            } else {
                out.println("<h2>Hello " + name + ", you are not eligible to vote yet.</h2>");
            }
        } catch (NumberFormatException e) {
            // Handle invalid age input
            out.println("<h2>Invalid input. Please enter a valid age.</h2>");
        } finally {
            out.close();
        }
    }
}
