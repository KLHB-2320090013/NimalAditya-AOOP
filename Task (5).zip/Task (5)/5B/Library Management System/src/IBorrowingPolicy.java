// IBorrowingPolicy.java
public interface IBorrowingPolicy {
    boolean canBorrow(Member member);
}

