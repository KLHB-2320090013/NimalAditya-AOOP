// LogLevel.java
public enum LogLevel {
    INFO,
    DEBUG,
    ERROR
}


