

public class Main {
    public static void main(String[] args) {
        
        logger Logger = logger.getInstance();
        Logger.log("Application started");
        Logger.log("User logged in");
        Logger.log("User performed an action");
        Logger.log("Application terminated");
    }
}

