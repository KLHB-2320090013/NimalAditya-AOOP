public interface MusicPlayer {
    void play(); 
}


