public interface MusicSource {
    void load(); 
}
