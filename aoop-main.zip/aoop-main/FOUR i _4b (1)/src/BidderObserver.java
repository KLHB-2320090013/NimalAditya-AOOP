public interface BidderObserver {
    void update(String message);
    String getName();

   
}
